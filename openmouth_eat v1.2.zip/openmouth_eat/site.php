<?php
/**
 * 饭来张口模块微站定义
 *
 * @author webfunny
 * @url http://api.nanhuaren.cn
 */
defined('IN_IA') or exit('Access Denied');

class Openmouth_eatModuleSite extends WeModuleSite {

	public function doWebCatalogs() {
		//这个操作被定义用来呈现 管理中心导航菜单
	}
	public function doWebShops() {
		//这个操作被定义用来呈现 管理中心导航菜单
	}
	public function doWebGoodsCatalogs() {
		//这个操作被定义用来呈现 管理中心导航菜单
	}
	public function doWebGoods() {
		//这个操作被定义用来呈现 管理中心导航菜单
	}
	public function doWebUsers() {
		//这个操作被定义用来呈现 管理中心导航菜单
	}
	public function doWebCoupons() {
		//这个操作被定义用来呈现 管理中心导航菜单
	}
	public function doWebOrders() {
		//这个操作被定义用来呈现 管理中心导航菜单
	}

}